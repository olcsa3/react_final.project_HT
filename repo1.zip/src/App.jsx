import { useState, useEffect } from 'react'
import './App.css'
import ProductList from './components/ProductList';
import ProductForm from './components/ProductForm';
import { Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import { AuthProvider } from './context/loginContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './components/Login';
import ProductDetails from './components/ProductDetails';
 
function App() {
  const [products, setProducts] = useState([]);
 
  const fetchProducts = async () => {
    try {
      const response = await fetch('http://localhost:3000/products');
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };
 
  useEffect(() => {
    fetchProducts();
  }, []);
 
  return (
    <AuthProvider>
      <NavBar />
      <Routes>
        <Route path="/" element={<ProductList products={products} onRefresh={fetchProducts} />} />
        <Route path="/login" element={<Login />} />
        <Route path="/manage" element={
          <ProtectedRoute>
            <ProductForm onRefresh={fetchProducts} />
          </ProtectedRoute>
        } />
        <Route path="/details/:id" element={<ProductDetails products={products} onRefresh={fetchProducts} />} />
      </Routes>
    </AuthProvider>
  );
}
 
export default App;