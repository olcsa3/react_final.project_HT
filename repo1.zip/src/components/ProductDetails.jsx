import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../context/loginContext";
import styles from "./ProductDetails.module.css";
 
const ProductDetails = ({ products, onRefresh }) => {
  const { id } = useParams();
  const { isLogged } = useAuth();
  const navigate = useNavigate();
  const product = products.find((p) => p.id === parseInt(id));
 
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(null);
 
  if (!product) return <div className={styles.empty}>Product not found.</div>;
 
  const startEdit = () => {
    setForm({ ...product });
    setEditing(true);
  };
 
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
 
  const handleSave = async () => {
    const response = await fetch(`http://localhost:3000/products/${product.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        name: form.name,
        description: form.description,
        img_url: form.img_url,
        price: form.price,
        stock: form.stock,
      }),
    });
    if (response.ok) {
      onRefresh();
      setEditing(false);
    } else {
      alert("Failed to update product.");
    }
  };
 
  const handleDelete = async () => {
    if (!window.confirm("Delete this product?")) return;
    const response = await fetch(`http://localhost:3000/products/${product.id}`, {
      method: "DELETE",
      headers: { authorization: localStorage.getItem("token") },
    });
    if (response.ok) {
      onRefresh();
      navigate("/");
    }
  };
 
  return (
    <main className={styles.page}>
      <button className={styles.back} onClick={() => navigate("/")}>← Back to shop</button>
      <div className={styles.card}>
        <div className={styles.imageSection}>
          {product.img_url ? (
            <img src={editing ? form.img_url : product.img_url} alt={product.name} className={styles.image} />
          ) : (
            <div className={styles.placeholder}>No image</div>
          )}
        </div>
 
        <div className={styles.info}>
          {!editing ? (
            <>
              <h1 className={styles.name}>{product.name}</h1>
              <p className={styles.description}>{product.description}</p>
              <div className={styles.meta}>
                <span className={styles.price}>${Number(product.price).toFixed(2)}</span>
                <span className={styles.stock}>{product.stock} in stock</span>
              </div>
              {isLogged && (
                <div className={styles.actions}>
                  <button className={styles.editBtn} onClick={startEdit}>Edit Product</button>
                  <button className={styles.deleteBtn} onClick={handleDelete}>Delete</button>
                </div>
              )}
            </>
          ) : (
            <div className={styles.editForm}>
              <h2 className={styles.editTitle}>Edit Product</h2>
              <label className={styles.label}>Name</label>
              <input className={styles.input} name="name" value={form.name} onChange={handleChange} />
 
              <label className={styles.label}>Description</label>
              <textarea className={styles.textarea} name="description" value={form.description || ""} onChange={handleChange} rows={4} />
 
              <label className={styles.label}>Image URL</label>
              <input className={styles.input} name="img_url" value={form.img_url || ""} onChange={handleChange} />
 
              <div className={styles.row}>
                <div>
                  <label className={styles.label}>Price ($)</label>
                  <input className={styles.input} name="price" type="number" value={form.price} onChange={handleChange} />
                </div>
                <div>
                  <label className={styles.label}>Stock</label>
                  <input className={styles.input} name="stock" type="number" value={form.stock} onChange={handleChange} />
                </div>
              </div>
 
              <div className={styles.actions}>
                <button className={styles.editBtn} onClick={handleSave}>Save Changes</button>
                <button className={styles.cancelBtn} onClick={() => setEditing(false)}>Cancel</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </main>
  );
};
 
export default ProductDetails;