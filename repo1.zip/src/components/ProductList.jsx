import ProductCard from "./ProductCard";
import styles from "./ProductList.module.css";
 
const ProductList = ({ products, onRefresh }) => {
  return (
    <main className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Our Collection</h1>
        <p className={styles.subtitle}>{products.length} items available</p>
      </div>
      {products.length === 0 ? (
        <div className={styles.empty}>
          <p>No products available yet.</p>
        </div>
      ) : (
        <div className={styles.grid}>
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onRefresh={onRefresh} />
          ))}
        </div>
      )}
    </main>
  );
};
 
export default ProductList;