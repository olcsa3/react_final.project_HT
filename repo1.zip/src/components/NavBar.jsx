import { NavLink } from "react-router-dom";
import { useAuth } from "../context/loginContext";
import styles from "./NavBar.module.css";
 
const NavBar = () => {
  const { isLogged, logout } = useAuth();
 
  return (
    <nav className={styles.navbar}>
      <div className={styles.links}>
        <NavLink to="/" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
          Shop
        </NavLink>
        {isLogged && (
          <NavLink to="/manage" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            Manage
          </NavLink>
        )}
        {!isLogged ? (
          <NavLink to="/login" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            Login
          </NavLink>
        ) : (
          <button onClick={logout} className={styles.logoutBtn}>Logout</button>
        )}
      </div>
    </nav>
  );
};
 
export default NavBar;