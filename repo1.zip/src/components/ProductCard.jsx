import { NavLink } from "react-router-dom";
import { useAuth } from "../context/loginContext";
import styles from "./ProductCard.module.css";
 
const ProductCard = ({ product, onRefresh }) => {
  const { isLogged } = useAuth();
 
  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;
    const response = await fetch(`http://localhost:3000/products/${product.id}`, {
      method: "DELETE",
      headers: { authorization: localStorage.getItem("token") },
    });
    if (response.ok) onRefresh();
  };
 
  return (
    <div className={styles.card}>
      {product.img_url ? (
        <div className={styles.imageWrap}>
          <img src={product.img_url} alt={product.name} className={styles.image} />
        </div>
      ) : (
        <div className={styles.imagePlaceholder}>
          <span>No image</span>
        </div>
      )}
      <div className={styles.body}>
        <h3 className={styles.name}>{product.name}</h3>
        <p className={styles.description}>{product.description}</p>
        <div className={styles.footer}>
          <span className={styles.price}>${Number(product.price).toFixed(2)}</span>
          <span className={styles.stock}>{product.stock} in stock</span>
        </div>
        <div className={styles.actions}>
          <NavLink to={`/details/${product.id}`} className={styles.detailsBtn}>
            View Details
          </NavLink>
          {isLogged && (
            <button onClick={handleDelete} className={styles.deleteBtn}>Delete</button>
          )}
        </div>
      </div>
    </div>
  );
};
 
export default ProductCard;