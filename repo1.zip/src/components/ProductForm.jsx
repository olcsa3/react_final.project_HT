import { useState } from "react";

const ProductForm = ({ onRefresh }) => {
  const [form, setForm] = useState({
    name: "",
    description: "",
    img_url: "",
    price: "",
    stock: "",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch("http://localhost:3000/products", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        name: form.name,
        description: form.description,
        img_url: form.img_url,
        price: Number(form.price),
        stock: Number(form.stock),
      }),
    });

    if (response.ok) {
      setForm({
        name: "",
        description: "",
        img_url: "",
        price: "",
        stock: "",
      });

      onRefresh();
      alert("Product created successfully!");
    } else {
      alert("Failed to create product.");
    }
  };

  return (
    <main style={{ maxWidth: "600px", margin: "2rem auto" }}>
      <h1>Add New Product</h1>

      <form onSubmit={handleSubmit}>
        <div>
          <label>Name</label>
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Description</label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            rows="4"
          />
        </div>

        <div>
          <label>Image URL</label>
          <input
            type="text"
            name="img_url"
            value={form.img_url}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Price</label>
          <input
            type="number"
            name="price"
            value={form.price}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label>Stock</label>
          <input
            type="number"
            name="stock"
            value={form.stock}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit">Create Product</button>
      </form>
    </main>
  );
};

export default ProductForm;