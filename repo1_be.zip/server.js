const express = require("express");
const db = require("./db");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const { authenticateToken, SECRET } = require("./auth");

const app = express();

app.use(cors());
app.use(express.json());

app.post("/register", (req, res) => {
    const { username, password } = req.body;
    if (!username || !password)
        return res.status(400).json({ message: "Username and password required" });

    db.query(
        "INSERT INTO users (username, password) VALUES (?, ?)",
        [username, password],
        (err) => {
            if (err) {
                if (err.code === "ER_DUP_ENTRY")
                    return res.status(409).json({ message: "Username already taken" });
                return res.status(500).json(err);
            }
            res.json({ message: "User created" });
        }
    );
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;
    console.log("Received:", username, password);
    console.log("Body:", req.body);
    if (!username || !password)
        return res.status(400).json({ message: "Username and password required" });

    db.query(
        "SELECT * FROM users WHERE username = ?",
        [username],
        (err, results) => {
            if (err) return res.status(500).json(err);
            if (results.length === 0)
                return res.status(400).json({ message: "Nincs ilyen user" });

            const user = results[0];
            if (password !== user.password)
                return res.status(400).json({ message: "Hibás jelszó" });

            const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: "2h" });
            res.json({ token });
        }
    );
});

app.get("/products", (req, res) => {
    db.query("SELECT * FROM products", (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});

app.get("/products/:id", (req, res) => {
    db.query(
        "SELECT * FROM products WHERE id = ?",
        [req.params.id],
        (err, results) => {
            if (err) return res.status(500).json(err);
            if (results.length === 0)
                return res.status(404).json({ message: "Product not found" });
            res.json(results[0]);
        }
    );
});

app.post("/products", authenticateToken, (req, res) => {
    const { name, description, img_url, price, stock } = req.body;
    if (!name || price == null || stock == null)
        return res.status(400).json({ message: "name, price and stock are required" });

    db.query(
        "INSERT INTO products (name, description, img_url, price, stock) VALUES (?, ?, ?, ?, ?)",
        [name, description, img_url, price, stock],
        (err, results) => {
            if (err) return res.status(500).json(err);
            res.status(201).json({ message: "Product created", id: results.insertId });
        }
    );
});

app.put("/products/:id", authenticateToken, (req, res) => {
    const { name, description, img_url, price, stock } = req.body;
    if (!name || price == null || stock == null)
        return res.status(400).json({ message: "name, price and stock are required" });

    db.query(
        "UPDATE products SET name=?, description=?, img_url=?, price=?, stock=? WHERE id=?",
        [name, description, img_url, price, stock, req.params.id],
        (err, results) => {
            if (err) return res.status(500).json(err);
            if (results.affectedRows === 0)
                return res.status(404).json({ message: "Product not found" });
            res.json({ message: "Product updated" });
        }
    );
});

app.delete("/products/:id", authenticateToken, (req, res) => {
    db.query(
        "DELETE FROM products WHERE id = ?",
        [req.params.id],
        (err, results) => {
            if (err) return res.status(500).json(err);
            if (results.affectedRows === 0)
                return res.status(404).json({ message: "Product not found" });
            res.json({ message: "Product deleted" });
        }
    );
});

app.listen(3000, () => console.log("Server fut a 3000-es porton"));